﻿Charles Regan     cwr2gb
To compile code use make and then run with ./hw5 (file name to test)
